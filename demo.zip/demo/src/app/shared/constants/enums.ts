export enum OperationType  {
    Like= 1,
    In,
    Equal,
    NotEqual,
    InBetween,
    GreaterThan,
    LessThan ,
    GreaterThanOrEqual,
    LessThanOrEqual,
    Is,
    NoOperator,
}
