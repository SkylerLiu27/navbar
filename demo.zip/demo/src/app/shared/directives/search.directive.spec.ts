import { SearchDirective } from './search.directive';

describe('SearchDirective', () => {
  it('should create an instance', () => {
    const directive = new SearchDirective();
    expect(directive).toBeTruthy();
  });
});
