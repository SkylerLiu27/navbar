export class Company {
    companyId: string;
    companyName: string;
    ein: string;
    industry: string;
    domainName: string;
}
