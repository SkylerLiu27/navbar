export class Person {
  personId: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  userId: string;
  companyId: string;
  companyName: string;
}
