export class Thumbnail {
    default: string;
    medium: string;
    high: string;
}
