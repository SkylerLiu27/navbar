export class UserAccount {
    userId: string;
    username: string;
    newPassword: string;
    defaultPassword: string;
}
