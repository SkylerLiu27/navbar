export class  UserLogin {
    username: string;
    password: string;
}
