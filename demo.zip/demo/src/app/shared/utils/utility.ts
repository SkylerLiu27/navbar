export class UtilityHelper {

  getRecordsCount(): number[] {
    return [20, 40, 60, 80, 100];
  }
}
